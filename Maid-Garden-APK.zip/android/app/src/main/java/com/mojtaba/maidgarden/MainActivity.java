package com.mojtaba.maidgarden;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;
    private String pendingAsset;
    private static final int SAVE_IMAGE = 31;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xff251b30);
        setContentView(web);
        web.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        web.requestApplyInsets();
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.matches("file:///android_asset/assets/maids/maid-(0[1-9]|1[0-2])-original\\.webp")) {
                    saveImage(url); return true;
                }
                return !url.startsWith("file:///android_asset/");
            }
        });
        web.setDownloadListener((url, userAgent, disposition, mime, size) -> saveImage(url));
        if (state == null || web.restoreState(state) == null) web.loadUrl("file:///android_asset/index.html");
    }
    private void saveImage(String url) {
        String prefix = "file:///android_asset/";
        if (!url.startsWith(prefix)) return;
        String asset = url.substring(prefix.length());
        if (!asset.matches("assets/maids/maid-(0[1-9]|1[0-2])-original\\.webp")) return;
        if (pendingAsset != null) return;
        pendingAsset = asset;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/webp");
        intent.putExtra(Intent.EXTRA_TITLE, asset.substring(asset.lastIndexOf('/') + 1));
        try { startActivityForResult(intent, SAVE_IMAGE); }
        catch (Exception ex) { pendingAsset = null; Toast.makeText(this, "No image save app available", Toast.LENGTH_SHORT).show(); }
    }
    @Override protected void onActivityResult(int request, int result, Intent intent) {
        super.onActivityResult(request, result, intent);
        if (request != SAVE_IMAGE) return;
        String asset = pendingAsset; pendingAsset = null;
        if (result != RESULT_OK || intent == null || intent.getData() == null || asset == null) return;
        Uri destination = intent.getData();
        new Thread(() -> {
            try (InputStream input = getAssets().open(asset); OutputStream output = getContentResolver().openOutputStream(destination)) {
                if (output == null) throw new java.io.IOException("Cannot write image");
                byte[] buffer = new byte[8192]; int read;
                while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                runOnUiThread(() -> Toast.makeText(this, "Image saved", Toast.LENGTH_SHORT).show());
            } catch (Exception ex) { runOnUiThread(() -> Toast.makeText(this, "Image could not be saved", Toast.LENGTH_SHORT).show()); }
        }).start();
    }
    @Override protected void onSaveInstanceState(Bundle state) { web.saveState(state); super.onSaveInstanceState(state); }
    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var d=document.querySelector('#art-viewer[open]')||document.querySelector('#modal[open]');if(d){d.close();return true}return false})()", handled -> {
            if (!"true".equals(handled)) new android.app.AlertDialog.Builder(this).setMessage("Exit Maid Garden?").setPositiveButton("Exit", (d,w)->finish()).setNegativeButton("Keep playing", null).show();
        });
    }
    @Override protected void onPause() { web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() { if (web != null) { web.destroy(); web = null; } super.onDestroy(); }
}
