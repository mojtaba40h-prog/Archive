"""Run the bundled game locally without installing dependencies."""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import webbrowser

root = Path(__file__).resolve().parent / 'www'
server = ThreadingHTTPServer(('127.0.0.1', 8765), partial(SimpleHTTPRequestHandler, directory=str(root)))
print('Maid Garden: http://127.0.0.1:8765 — Ctrl+C to stop')
webbrowser.open('http://127.0.0.1:8765')
try:
    server.serve_forever()
except KeyboardInterrupt:
    server.server_close()
