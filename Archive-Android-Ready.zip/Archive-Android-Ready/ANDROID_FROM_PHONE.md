# Archive → Android APK, from a phone

## What is included
The original Arabic/English teaching app and all offline media are intact. The added Capacitor v8 configuration and GitHub Actions workflow build a **debug APK**, not a verified/production release. No APK is already compiled in this ZIP.

## From your Android phone
1. Extract this ZIP using a file manager, preserving directories, including `.github/workflows` (hidden folder).
2. Create a **new** GitHub repository (for example `Archive-Android`) and upload the **contents** of `Archive-Android-Ready`, not an outer ZIP. GitHub's mobile web Upload files UI may require uploading files in smaller groups and preserving paths; a mobile Git client that can commit an entire folder is more reliable. Do not upload your signing key or passwords.
3. Confirm `.github/workflows/android-apk.yml` exists in your repository.
4. Open repository → **Actions** → **Build Archive Android APK** → **Run workflow**. Pushes to `main` / `master` also run it automatically.
5. Once the run succeeds, open its Artifacts → `Archive-debug-APK` → download ZIP → extract `app-debug.apk` → install.
6. Android may warn about installing from outside the Play Store. Enable installation from your trusted file manager when prompted and review the source first.

## Offline functionality / progress
The entire UI, two curricula, teachers, and images are embedded in the Android package. The existing progress is saved in WebView local storage; it does not migrate automatically from your browser. Use Archive's built-in export/import backup, and test this on a physical Android phone. Export progress before uninstalling or clearing app data.

## Important limitations
- A debug APK is automatically signed with an ephemeral DEBUG key in GitHub CI and is for personal tests, NOT public release or verified developer identity. This workflow generates a new native project on each run. Do not rely on it for upgradable releases.
- For stable updates: create a RELEASE signing key once, keep it safe, configure a permanent release-signing workflow with GitHub Actions encrypted secrets, and build a signed release APK / AAB. Losing the release key can prevent upgrades outside managed Play signing.
- Google Play Protect warnings are separate from signing. Android developer identity verification / store registration are separate processes, potentially with eligibility rules and fees.
- Backup export/download and file picker/import should be tested on device as WebView behavior differs from desktop browsers.
- Modify `com.mojtaba.archive` BEFORE publishing if you need a different final application ID.
