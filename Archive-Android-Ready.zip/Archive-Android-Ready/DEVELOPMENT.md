# Archive — HTML foundation

Open `index.html` in a modern browser. It is self-contained and uses no external libraries, network requests, fonts or services. The header language selector switches the entire interface, all 20 lessons, all 40 questions, and the source outline between English and Arabic. Japanese instructor reactions have optional subtitles in the selected app language. Language choice is saved locally and included in progress backups. Older backups without a language field remain compatible.

## Included
- Four selectable maid identities with empty artwork spaces; shared reaction dialogue.
- A+ preview: 4 units, 20 adapted short lessons, 40 original practice questions.
- Sequential lesson unlocks, two-question lesson checks (100% pass), and four unit reviews (80% pass).
- Local progress, levels, XP, Pyroxene, study-day streak, achievements, daily first-new-lesson bonus.
- First lesson completion: 20 XP + 10 Pyroxene. First unit-review pass: 50 XP + 20 Pyroxene. Daily bonus: 5 Pyroxene. Replays do not repeat rewards.
- JSON progress export/import, with replacement confirmation and structural validation.
- CCNA, Security+ and other paths are explicitly unavailable placeholders.
- Responsive layout and keyboard-accessible text controls; reserved icon and artwork spaces.

## Content and coverage
Source: David L. Prowse, *CompTIA A+ Core 1 (220-1101) and Core 2 (220-1102) Exam Cram*, Pearson, 2022. Supplied 110-page preview, chapters 1–4, printed pages 7–69 (PDF pages 46–108). Lesson-level printed-page references are visible in the app. Adapted study notes and newly authored questions are concise, not verbatim textbook reproductions. The source PDF is not bundled.

Only the first four chapters have teaching content in the supplied preview. The 65-chapter outline is informational; remaining chapter bodies are not available. Course percentages describe the 20 included lessons, not the full certification. Edition labels follow the supplied source; newer exam alignment has not been verified.

## Editing
`index.html` is the runnable, self-contained deliverable. `template.html` is its editable source with the `__CURRICULUM__` token. `curriculum.json` is the editable curriculum. After changing either source file, run `python3 rebuild.py` from this directory to regenerate `index.html`.

Add future artwork under `assets/maids/` and `assets/icons/`. No images or icon glyphs are loaded now. The `art()` and `icon()` functions define the reserved spaces. Future character expressions and individual dialogue sets can extend `MAIDS` without changing course content.

## Progress
Uses `localStorage` key `archive.progress.v1`. Data belongs to the current browser/WebView origin; browsers may restrict storage for local files. An in-app notice reports unavailable storage. Export a backup before moving devices or packaging. Imports replace local progress after confirmation. This is an offline prototype with no accounts, cloud synchronization, anti-cheat or purchases.

## Android packaging later
This ZIP contains web source, not an APK. It can later be packaged with Capacitor or an Android WebView wrapper. Use bundled local assets, enable JavaScript and DOM storage, and test Android Back navigation, edge-to-edge/safe-area behavior and lifecycle restoration. Progress import/export currently uses browser file APIs; verify Android file chooser/download support in the selected wrapper and add native file handling if needed. Test on a real Android device before release. No Android build toolchain or wrapper is included.

## Verification
JavaScript syntax and automated application-logic checks passed (progression, scoring, reward idempotence, source data, validation and screen rendering). Browser screenshot/visual verification was unavailable because this environment has no installed browser executable. Android device behavior has not yet been tested.

## Arabic layout and fonts
Arabic uses `lang="ar"`, `dir="rtl"`, right-aligned controls, mirrored callout accents and increased line spacing. Latin technical terms and numeric ranges are isolated with `bdi` to preserve reading order. Japanese dialogue remains LTR. DejaVu Sans regular and bold Arabic-supporting font subsets are embedded as WOFF data in the standalone HTML, so no font download or Internet connection is needed; the font license is included in the HTML and assets/fonts/LICENSE.txt. English retains its system font. Changing language during a check preserves its question, choice and score; lesson IDs and rewards are shared across languages.

Edit `curriculum-ar.json` for Arabic content and `template.html` for UI translations. `localization.js` is a reference copy of the embedded localization helpers; the template is the runtime authority. Run `python3 rebuild.py` after edits. `node test_logic.cjs` and `node test_bilingual.cjs` check application behavior and translation structure. Browser/device visual verification remains pending.

## Artwork update
Sol's standing transparent cutout is adapted from the supplied character sheet using image generation; original face expressions are displayed as sprite views of the supplied sheet. Neutral, happy and encouraging reactions are connected to lesson events. Other maid illustrations remain empty. The supplied icon collection was adapted into an icon atlas; SVG viewBox windows display its icons without separate image cuts. All active images are embedded into index.html for offline, single-file use. Local asset copies are included for future edits. Generated art is an adaptation, not pixel-identical extraction. Voices are not included. Existing progress IDs and language settings are preserved. Browser screenshot validation is still unavailable in this environment.

## Selene update
Added Selene as an independent fifth maid with an adapted standing illustration and original sheet portraits for neutral, happy and encouraging reactions. Switching between Sol and Selene preserves all progress. Arabic and English labels and backup validation support the new ID `selene`.

## Visual study guide and interface refresh
The supplied mobile-devices guide is embedded once and displayed through SVG viewBox panels, without altering the source bitmap. Twelve panels are mapped to the 20 lessons; some lessons share the relevant overview. Captions and accessible descriptions are provided in English and Arabic. Original English labels inside the image are retained. The enlarge button opens a native dialog; Escape or Close dismisses it in supporting browsers.

The interface now uses navy panels, violet-to-blue action buttons, highlighted selected maids, stronger character presentation and light lesson reading surfaces, inspired by the supplied interface concept. This is a styled implementation of the existing app, not an exact copy of the concept art. No new courses, points rules, progress IDs or graphics for unavailable maids were introduced. Browser screenshot and Android visual validation remain pending; logic, source-image viewport bounds and bilingual diagram mappings passed automated checks.

## Clara, Reina and practice expansion
Added Clara artwork to her existing identity and Reina artwork to the legacy `rina` identity, preserving old selections. The two supplied sheets provide original face-expression sprite windows; standing illustrations are adapted transparent assets. Sol and Selene remain available, while Luna still has an empty artwork slot.

New home actions open Saved lessons and Practice center. Lesson bookmarks persist locally and in backups. Mixed practice shuffles up to ten questions from completed lessons. Wrong answers in normal checks or practice enter a deduplicated mistake queue; later correct answers remove them. Mistake review includes up to ten queued questions per session, including mistakes from an unfinished lesson. Practice completion is counted once, does not unlock lessons, and awards no extra XP or currency. Practice questions resolve from stable IDs so the app language can change mid-session. Older backups acquire empty bookmark/mistake lists and a zero session count automatically. All new screens support Arabic and English. No additional certification-course content was added in this update.

Checks passed for bookmarks, malformed backup rejection, unique mistake tracking and clearing, practice scoring, repeat-action protection, no repeat currency, bilingual practice, and Clara/Reina asset selection. Visual browser and Android device checks remain pending.

## Applied questions and training records
Reworked the first question of each lesson into a practical scenario and replaced weak distractors in the second question. The bank still contains 40 questions, now with four choices each in both languages. Stable lesson/question indices preserve old mistake references. Quiz and practice choice orders are shuffled per attempt; displayed choices retain their original answer indices so correctness survives language changes.

Practice center now supports all units or one unit and a requested session length of 5, 10 or 20 questions. It uses only the available eligible questions when fewer exist; a message explains empty filtered pools. Unit filtering also applies to mistake review. The training-record screen retains the latest 30 completed checks/practice sessions, with score, date, type and selected unit. Unit cards show queued mistake counts and averages of recorded unit-specific attempts; mixed sessions spanning all units are not attributed to an individual unit. These are descriptive results, not a certification-readiness assessment. A unit card can return you to filtered practice.

History is included in progress exports and validated on import. Old backups receive an empty history automatically. Completion-history writes are protected against repeated finish actions; practice still provides no extra XP or currency. Tests passed for all question choice counts and bilingual parity, shuffling, filtered pools, history bounds, invalid records, repeat finish protection and the new screen renders. Browser/Android visual checks remain pending.

## Four-teacher interface, library and notes
Removed Luna from the selectable roster, leaving Sol, Selene, Clara and Reina. Existing local saves and imported backups with the legacy Luna ID migrate to Sol without changing points, completed lessons, notes or other records. The legacy ID is accepted solely for migration.

Added a learning library with search across English and Arabic titles, introductions and key ideas, plus unit and completion/saved filters. Arabic search normalizes common diacritics and spelling variants. Results respect existing lesson locks. Added per-lesson autosaved plain-text notes (maximum 3,000 characters), included in progress exports. Notes use escaped text and remain unchanged when switching app languages. Added a daily planning goal of 1, 3 or 5 completed checks/practice sessions; repeated review attempts count, and no extra currency is awarded. The goal uses the existing session history and local date.

The interface now has a five-item bottom navigation including Practice, grouped navigation states, sticky top controls, a four-teacher selection grid, improved mobile sizing and focused note/search controls. Tests passed for roster removal, legacy save migration without progress loss, note escaping and bounds, bilingual search, filters and daily goal counts. Browser screenshot and real Android layout validation remain pending.
