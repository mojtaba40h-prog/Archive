import json, sys
from playwright.sync_api import sync_playwright
import os
root='file://'+os.path.abspath(os.path.join(os.path.dirname(__file__),'..','index.html'))
fails=[]
def check(c,msg):
    print(('PASS ' if c else 'FAIL ')+msg)
    if not c: fails.append(msg)
with sync_playwright() as p:
    b=p.chromium.launch()
    for vp in [(390,844),(1280,800)]:
        ctx=b.new_context(viewport={'width':vp[0],'height':vp[1]},accept_downloads=True)
        pg=ctx.new_page(); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto(root)
        tag=f'[{vp[0]}] '
        # welcome -> name -> maid
        check('A new chapter' in pg.inner_text('#view'),tag+'welcome shown for new user')
        pg.fill('#learner-name','Tester'); pg.click('[data-action=welcome-next]')
        check(pg.locator('.maid-card').count()==4,tag+'4 teacher cards')
        pg.click('[data-maid=sol]')
        check(pg.locator('#toast.success').is_visible(),tag+'success toast on teacher select')
        check('Welcome back' in pg.inner_text('#view') and 'Tester' in pg.inner_text('#view'),tag+'home after selection')
        # continue -> lesson -> quiz
        pg.click('[data-action=continue]')
        check(pg.locator('.lesson-intro').count()==1,tag+'lesson opens from Continue')
        pg.click('[data-bookmark]'); check(pg.get_attribute('[data-bookmark]','aria-pressed')=='true',tag+'bookmark toggles')
        pg.fill('#lesson-note','hello note')
        pg.click('[data-quiz]')
        check(pg.locator('.focus-screen').count()==1 and not pg.locator('#nav').is_visible(),tag+'focus mode hides nav in quiz')
        check(pg.locator('[data-action=check]').is_disabled(),tag+'check disabled until choice')
        for i in range(2):
            ans=pg.evaluate('quiz.questions[quiz.index].answer')
            pg.click(f'[data-choice="{ans}"]')
            check(pg.get_attribute(f'[data-choice="{ans}"]','aria-pressed')=='true',tag+'option selected state')
            pg.click('[data-action=check]')
            check(pg.locator('.option.is-correct').count()==1,tag+'correct option highlighted')
            # locked options cannot change answer
            other=pg.evaluate('quiz.orders[quiz.index].find(i=>i!==quiz.questions[quiz.index].answer)')
            pg.click(f'[data-choice="{other}"]',force=True)
            check(pg.evaluate('quiz.choice')==ans,tag+'answer locked after check')
            pg.click('[data-action=next-question]')
        check('A step forward' in pg.inner_text('#view'),tag+'results pass screen')
        st=json.loads(pg.evaluate("localStorage.getItem('archive.progress.v1')"))
        check(st['xp']==20 and st['pyroxene']==15 and 'u1l1' in st['completed'],tag+'progress saved under archive.progress.v1 with rewards')
        check(st['notes'].get('u1l1')=='hello note' and 'u1l1' in st['bookmarks'],tag+'notes+bookmarks persisted')
        pg.click('[data-action=result-next]')
        check(pg.locator('.lesson-row.is-current').count()==1 and pg.locator('.lesson-row:disabled').count()==3,tag+'unit: 1 current, 3 locked')
        # nav
        if vp[0]>=900:
            check(pg.locator('#nav').is_visible() and pg.evaluate("getComputedStyle(document.querySelector('#nav')).flexDirection")=='column',tag+'desktop side rail')
        for n in ['courses','practice','maids','profile','home']:
            pg.click(f'#nav [data-go={n}]'); check(pg.locator('#nav button.active').get_attribute('data-go')==n,tag+f'nav -> {n}')
        # language switch & persistence
        pg.select_option('#app-language','ar')
        check(pg.evaluate('document.documentElement.dir')=='rtl',tag+'RTL on Arabic')
        pg.reload()
        check(pg.evaluate('document.documentElement.dir')=='rtl' and pg.evaluate('state.xp')==20,tag+'language+progress survive reload')
        pg.select_option('#app-language','en')
        # library search & empty state
        pg.click('#nav [data-go=courses]'); pg.click('[data-go=library]')
        pg.fill('#lesson-search','zzzzqq'); check(pg.locator('#search-results .empty').count()==1,tag+'library empty state')
        pg.fill('#lesson-search','memory'); check(pg.locator('#search-results .lesson-row').count()>=1,tag+'library search results')
        # practice
        pg.click('#nav [data-go=practice]'); pg.click('[data-drill=mixed]')
        check(pg.locator('.focus-screen').count()==1,tag+'drill opens')
        pg.click('#view [data-go=practice]')
        # history empty
        pg.evaluate('state.history=[];render()'); pg.click('[data-go=history]'); check(pg.locator('.empty button').count()==1,tag+'history empty state with action')
        # profile export / import
        pg.click('#nav [data-go=practice]')
        pg.click('#nav [data-go=profile]')
        with pg.expect_download() as d: pg.click('[data-action=export]')
        path=d.value.path(); data=json.load(open(path))
        check(data['xp']==20,tag+'export downloads valid JSON')
        bad='/tmp/bad.json'; open(bad,'w').write('{"nope":1}')
        pg.set_input_files('#import-file',bad); pg.wait_for_timeout(200)
        check(pg.locator('#toast.error').is_visible(),tag+'invalid import -> error toast')
        pg.once('dialog',lambda dlg:dlg.accept())
        pg.set_input_files('#import-file',path); pg.wait_for_timeout(300)
        check(pg.locator('#toast.success').is_visible(),tag+'valid import -> success toast')
        # visual dialog
        pg.evaluate("currentLesson='u1l3';go('lesson')")
        pg.click('[data-visual]'); check(pg.evaluate("document.getElementById('visual-dialog').open"),tag+'enlarge dialog opens')
        pg.keyboard.press('Escape'); check(not pg.evaluate("document.getElementById('visual-dialog').open"),tag+'Escape closes dialog')
        # keyboard focus visible on tab
        pg.keyboard.press('Tab'); 
        ov=pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth')
        check(ov<=0,tag+'no horizontal scroll')
        # touch target sizes
        small=pg.evaluate("""()=>[...document.querySelectorAll('#view button,#nav button,select,input[type=text],input[type=search]')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&r.height<44}).map(e=>e.className+':'+Math.round(e.getBoundingClientRect().height))""")
        check(not small,tag+'all controls >=44px tall '+str(small[:3]))
        check(not errs,tag+'no JS errors '+str(errs))
        ctx.close()
    # legacy save (original schema, luna maid) loads
    ctx=b.new_context(viewport={'width':390,'height':844}); pg=ctx.new_page()
    pg.goto(root)
    legacy={"version":1,"lang":"ar","name":"قديم","maid":"luna","completed":{"u1l1":100,"u1l2":100},"unitTests":{},"xp":40,"pyroxene":25,"days":["2026-10-01"],"dailyClaims":[],"lastLesson":"u1l2","showTranslation":True}
    pg.evaluate("s=>localStorage.setItem('archive.progress.v1',s)",json.dumps(legacy)); pg.reload()
    check(pg.evaluate('state.maid')=='sol' and pg.evaluate('state.xp')==40 and pg.evaluate('count()')==2,'legacy save (luna, old schema) migrates without loss')
    check('قديم' in pg.inner_text('#view'),'legacy name shown on home')
    ctx.close(); b.close()
print('\nFAILS:',fails)
sys.exit(1 if fails else 0)
