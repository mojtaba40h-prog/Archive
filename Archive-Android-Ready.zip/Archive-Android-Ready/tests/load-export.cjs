const fs=require('fs'),p=require('path'),root=p.resolve(__dirname,'..');
module.exports=()=>{
const en=fs.readFileSync(p.join(root,'data/curriculum.json'),'utf8');
const ar=fs.readFileSync(p.join(root,'data/curriculum-ar.json'),'utf8');
const code=fs.readFileSync(p.join(root,'data/curriculum.js'),'utf8')+'\n'+fs.readFileSync(p.join(root,'data/curriculum-ar.js'),'utf8')+'\n'+fs.readFileSync(p.join(root,'js/app.js'),'utf8');
return '<script id="curriculum" type="application/json">'+en+'</script><script id="curriculum-ar" type="application/json">'+ar+'</script><script>\n'+code+'</script>';
};
