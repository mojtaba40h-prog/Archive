const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const target = path.join(root, 'www');
fs.rmSync(target, { recursive: true, force: true });
fs.mkdirSync(target, { recursive: true });
for (const filename of ['index.html']) fs.copyFileSync(path.join(root, filename), path.join(target, filename));
for (const folder of ['assets', 'css', 'js', 'data']) fs.cpSync(path.join(root, folder), path.join(target, folder), { recursive: true });
console.log('Offline web files prepared in www/');
