from pathlib import Path
import json
root=Path(__file__).resolve().parent
for stem,lang in [('curriculum','EN'),('curriculum-ar','AR')]:
    raw=(root/(stem+'.json')).read_text(encoding='utf-8')
    json.loads(raw)
    (root/(stem+'.js')).write_text('window.ARCHIVE_COURSE_'+lang+' = '+raw+';\n',encoding='utf-8')
print('Updated offline course scripts')
