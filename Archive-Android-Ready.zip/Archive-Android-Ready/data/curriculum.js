window.ARCHIVE_COURSE_EN = {
  "source": {
    "title": "CompTIA A+ Core 1 (220-1101) and Core 2 (220-1102) Exam Cram",
    "author": "David L. Prowse",
    "year": 2022,
    "pdfPages": 110,
    "coverage": "Chapters 1–4 only; printed pages 7–69; PDF pages 46–108.",
    "note": "Concise adapted study notes and newly written practice questions based on the supplied preview. This is not the complete book or a complete certification course. The course retains the preview’s 220-1101/220-1102 edition labels; no claim of alignment with a newer exam is made."
  },
  "units": [
    {
      "id": "u1",
      "title": "Laptop Hardware & Components",
      "chapter": 1,
      "pages": "7–28",
      "lessons": [
        {
          "id": "u1l1",
          "title": "Power & Safe Servicing",
          "pages": "8–11",
          "intro": "A laptop depends on a complete power chain: wall outlet, adapter, DC input and battery. Diagnose the chain before replacing components.",
          "points": [
            "Check the outlet, adapter compatibility, cable and DC jack before opening the laptop.",
            "Shut down, disconnect external power and follow the service manual to disconnect the battery before servicing. Use ESD precautions.",
            "A swollen battery is a safety issue. Stop using the device and arrange qualified service; never puncture or compress it."
          ],
          "scenario": "A laptop runs until its battery empties even though the charger is plugged in. Check whether the adapter is compatible and whether the charging connection works.",
          "questions": [
            {
              "prompt": "A laptop runs until its battery empties while connected to a charger. The wall outlet works. What is the best next check?",
              "options": [
                "Verify adapter compatibility and inspect the DC connection",
                "Replace the battery immediately",
                "Reinstall the battery-status application",
                "Replace the motherboard before testing the adapter"
              ],
              "answer": 0,
              "explanation": "A working outlet rules out one link, not the entire power path. A wrong adapter or poor DC connection can leave the laptop running only on battery."
            },
            {
              "prompt": "What should you do with a visibly swollen laptop battery?",
              "options": [
                "Keep charging it while monitoring the percentage",
                "Stop using it and arrange safe service",
                "Discharge it with a heavy workload",
                "Compress the case to restore its shape"
              ],
              "answer": 1,
              "explanation": "A swollen battery needs safe handling and qualified replacement, not further charging."
            }
          ]
        },
        {
          "id": "u1l2",
          "title": "Keyboards & Touchpads",
          "pages": "11–16",
          "intro": "Laptop keyboards use compact layouts and special keys. Touchpads provide pointing input and can be disabled independently of the keyboard.",
          "points": [
            "Fn combinations can control brightness, wireless networking, audio and displays; mappings depend on the manufacturer.",
            "Unexpected numbers while typing may indicate that Num Lock is enabled.",
            "Check touchpad settings and accidental palm contact before suspecting a hardware failure. An external keyboard or mouse helps isolate faults."
          ],
          "scenario": "Letters become numbers on part of a compact keyboard. Inspect Num Lock before replacing the keyboard.",
          "questions": [
            {
              "prompt": "An external keyboard types normally, but several letter keys on a compact laptop produce numbers. Which action is most appropriate first?",
              "options": [
                "Replace the keyboard ribbon cable",
                "Disable Num Lock and retest the affected keys",
                "Reinstall all USB drivers",
                "Replace the built-in keyboard"
              ],
              "answer": 1,
              "explanation": "The symptom matches an embedded numeric keypad being enabled. Test the relevant setting before replacing hardware."
            },
            {
              "prompt": "What can help isolate a built-in keyboard fault?",
              "options": [
                "Connect a known-good external keyboard",
                "Replace the display cable first",
                "Disable every input device in firmware",
                "Replace the motherboard without testing"
              ],
              "answer": 0,
              "explanation": "An external keyboard helps distinguish a built-in keyboard problem from a wider input problem."
            }
          ]
        },
        {
          "id": "u1l3",
          "title": "Laptop Memory",
          "pages": "17–19",
          "intro": "RAM temporarily holds active programs and data. Many serviceable laptops use small-outline memory modules called SODIMMs.",
          "points": [
            "DDR3 SODIMMs use 204 pins; DDR4 SODIMMs use 260 pins. These generations are not interchangeable.",
            "Confirm supported memory type and capacity in the manufacturer documentation. Some systems have soldered RAM.",
            "After an upgrade, check detection in firmware and the operating system. If memory is missing, power down and check seating."
          ],
          "scenario": "The reported RAM capacity does not change after an upgrade. Check compatibility and reseat the module safely before buying another one.",
          "questions": [
            {
              "prompt": "A laptop supports DDR4 SODIMMs. After adding a compatible module, firmware still reports the old capacity. What should you do next?",
              "options": [
                "Install a DDR3 module of the same capacity",
                "Change the display adapter driver",
                "Power down, disconnect power and check the module seating",
                "Increase the operating-system paging file"
              ],
              "answer": 2,
              "explanation": "Firmware failing to detect compatible RAM points toward installation or hardware detection. A paging file cannot make firmware recognize an unseated module."
            },
            {
              "prompt": "New compatible RAM is not detected. What is a sensible next check?",
              "options": [
                "Reseat it with power disconnected",
                "Force a different DDR generation into the slot",
                "Reseat it while the system is running",
                "Increase virtual memory to make firmware detect it"
              ],
              "answer": 0,
              "explanation": "Incomplete insertion can prevent detection; disconnect power before reseating."
            }
          ]
        },
        {
          "id": "u1l4",
          "title": "Storage & Upgrades",
          "pages": "19–21",
          "intro": "Storage retains files when power is removed. Laptop drives may use flash memory, rotating magnetic disks or a hybrid design.",
          "points": [
            "SSDs have no moving mechanical parts. HDDs use rotating magnetic platters.",
            "A 2.5-inch SATA drive has separate data and power connections.",
            "M.2 describes a form factor. Confirm the supported interface, dimensions and keying before selecting a replacement. Back up data before changing drives."
          ],
          "scenario": "An older laptop has a slow mechanical drive. A compatible SSD can improve responsiveness, but plan the backup or migration first.",
          "questions": [
            {
              "prompt": "You want to replace a 2.5-inch SATA HDD with an M.2 drive. Which finding is required before recommending the upgrade?",
              "options": [
                "The replacement has a larger capacity",
                "The laptop has a USB-C port",
                "The drive brand matches the laptop brand",
                "The laptop supports the drive’s slot, interface and dimensions"
              ],
              "answer": 3,
              "explanation": "A capacity increase or an unrelated connector does not establish compatibility. M.2 form factor and interface support must match the laptop."
            },
            {
              "prompt": "What must you verify before buying an M.2 upgrade?",
              "options": [
                "Only its storage capacity",
                "Only the M.2 label",
                "Slot, interface and physical compatibility",
                "Only whether it has flash memory"
              ],
              "answer": 2,
              "explanation": "A drive must match the laptop’s supported slot and interface as well as its physical size."
            }
          ]
        },
        {
          "id": "u1l5",
          "title": "Communications & Physical Privacy",
          "pages": "21–24",
          "intro": "Laptops communicate through Ethernet, Wi-Fi, Bluetooth and sometimes cellular radios. Physical protection and authentication address different risks.",
          "points": [
            "Wi-Fi connects to a WLAN; Bluetooth commonly connects nearby accessories; cellular provides WWAN access.",
            "Check wireless toggles and OS settings when a radio appears unavailable.",
            "A cable lock discourages theft. Biometrics support authentication. Combine independent authentication factors when stronger access protection is required."
          ],
          "scenario": "A laptop cannot see Wi-Fi networks after a function key was pressed. Check the wireless toggle before reinstalling the adapter.",
          "questions": [
            {
              "prompt": "Wi-Fi stops working immediately after a function-key shortcut is pressed, but Ethernet still works. What should you check first?",
              "options": [
                "The wireless radio toggle and OS adapter state",
                "The Ethernet cable category",
                "The laptop cable lock",
                "The storage drive interface"
              ],
              "answer": 0,
              "explanation": "A radio toggle can disable Wi-Fi independently of Ethernet. Start with the setting most directly connected to the change."
            },
            {
              "prompt": "What is the main purpose of a laptop cable lock?",
              "options": [
                "Prevent physical theft",
                "Encrypt files at rest",
                "Verify the user’s fingerprint",
                "Prevent all remote access"
              ],
              "answer": 0,
              "explanation": "A cable lock physically anchors a device; it does not encrypt data."
            }
          ]
        }
      ]
    },
    {
      "id": "u2",
      "title": "Mobile Device Displays",
      "chapter": 2,
      "pages": "29–38",
      "lessons": [
        {
          "id": "u2l1",
          "title": "LCD, LED Backlights & OLED",
          "pages": "30–31",
          "intro": "Display technology affects how an image is produced and lit. An LED-backlit LCD is still an LCD; OLED pixels emit their own light.",
          "points": [
            "LCD panels modulate a separate light source. Older backlights may use CCFL lamps; others use LEDs.",
            "TN, IPS and VA are LCD panel technologies with different viewing-angle, response and contrast tradeoffs.",
            "OLED uses light-emitting organic material and does not require a separate LCD-style backlight."
          ],
          "scenario": "A specification says “LED-backlit IPS.” Identify it as an LCD using an IPS panel and LED illumination.",
          "questions": [
            {
              "prompt": "A specification lists an “LED-backlit IPS display.” Which description is correct?",
              "options": [
                "Each pixel emits organic light without a backlight",
                "An LCD panel uses IPS technology and an LED light source",
                "An IPS panel must use a CCFL lamp",
                "LED describes the touch-input layer"
              ],
              "answer": 1,
              "explanation": "IPS describes an LCD panel technology. LED-backlit identifies its separate illumination source; it does not make the panel OLED."
            },
            {
              "prompt": "Which display type has self-emitting pixels?",
              "options": [
                "CCFL-backlit LCD",
                "OLED",
                "LED-backlit LCD",
                "IPS with a separate backlight"
              ],
              "answer": 1,
              "explanation": "OLED pixels emit light rather than filtering a separate backlight."
            }
          ]
        },
        {
          "id": "u2l2",
          "title": "Backlights & Inverters",
          "pages": "31–33",
          "intro": "Older CCFL-backlit laptop displays use an inverter to provide the AC voltage required by the lamp. This is distinct from modern LED backlighting.",
          "points": [
            "An inverter converts DC input to AC for a CCFL backlight.",
            "A faint image visible under a flashlight can indicate a failed illumination system rather than total loss of the video signal.",
            "Display repair can involve high voltage and fragile parts. Power down and follow qualified service procedures."
          ],
          "scenario": "An older display looks black but shows a faint desktop under a flashlight. Investigate the backlight system.",
          "questions": [
            {
              "prompt": "An older CCFL-backlit laptop shows a faint desktop under a flashlight, while an external monitor works normally. Which fault is most consistent?",
              "options": [
                "A disconnected keyboard ribbon",
                "A full storage drive",
                "A backlight or inverter failure",
                "An incorrect Wi-Fi password"
              ],
              "answer": 2,
              "explanation": "The faint image suggests the panel still receives image data. Loss of illumination makes the backlight system a stronger suspect than storage or input devices."
            },
            {
              "prompt": "A faint desktop appears when a flashlight shines on a dark screen. Which subsystem is suspect?",
              "options": [
                "Storage capacity",
                "Backlight system",
                "Keyboard input controller",
                "Wireless adapter"
              ],
              "answer": 1,
              "explanation": "The image signal is present, but the screen is not being lit normally."
            }
          ]
        },
        {
          "id": "u2l3",
          "title": "Digitizers, Cameras & Microphones",
          "pages": "33–34",
          "intro": "A digitizer converts touch or stylus input into digital information. It is a different function from displaying the image.",
          "points": [
            "A visible image with failed touch input can point to the digitizer, its connection or its driver.",
            "Laptop cameras and microphones are commonly installed near the top of the display assembly.",
            "Check privacy switches, permissions and disabled-device settings before replacing a camera or microphone."
          ],
          "scenario": "Video works but no audio is recorded. Check the selected microphone and permissions rather than replacing the display.",
          "questions": [
            {
              "prompt": "A tablet displays an image normally but no longer responds to touch. Which subsystem should you investigate before replacing the image panel?",
              "options": [
                "The battery charging adapter only",
                "The storage partition table",
                "The Wi-Fi antenna",
                "The digitizer, its connection and its driver"
              ],
              "answer": 3,
              "explanation": "Image output and touch input are separate functions. Normal image output does not prove that the digitizer path is healthy."
            },
            {
              "prompt": "What should you check before replacing an apparently inactive webcam?",
              "options": [
                "The battery’s charge-cycle count",
                "Camera privacy settings and permissions",
                "The SSD partition layout",
                "The laptop’s external display mode"
              ],
              "answer": 1,
              "explanation": "A hardware switch or software permission can disable an otherwise working camera."
            }
          ]
        },
        {
          "id": "u2l4",
          "title": "Wi-Fi Cards & Antenna Routing",
          "pages": "35–36",
          "intro": "A laptop Wi-Fi adapter and its antenna system work together. Antenna leads may run through the hinge and around the display assembly.",
          "points": [
            "Internal adapters can use M.2 or Mini PCIe form factors; confirm compatibility before replacement.",
            "M.2 2230 describes a 22 mm by 30 mm card.",
            "Reconnect delicate antenna leads as specified by the manufacturer and avoid pinching wires in the hinge. A MAC address identifies a network interface."
          ],
          "scenario": "Wi-Fi reception drops after display repair. Inspect antenna connections and routing before changing the network.",
          "questions": [
            {
              "prompt": "Wi-Fi reception becomes poor after replacing a laptop display assembly. It improves when the laptop is next to the router. What should you inspect first?",
              "options": [
                "Antenna lead connections and routing around the hinge",
                "The saved email signature",
                "The keyboard language setting",
                "The SSD file system"
              ],
              "answer": 0,
              "explanation": "The repair location and distance-sensitive symptom fit an antenna problem. Inspect delicate leads and hinge routing before changing unrelated software."
            },
            {
              "prompt": "Reception worsens after hinge repair. What should you inspect?",
              "options": [
                "The saved screen resolution",
                "Antenna leads and routing",
                "The laptop’s numeric-keypad mode",
                "The storage boot order"
              ],
              "answer": 1,
              "explanation": "A disconnected or pinched antenna cable can reduce wireless reception."
            }
          ]
        }
      ]
    },
    {
      "id": "u3",
      "title": "Accessories & Ports",
      "chapter": 3,
      "pages": "39–48",
      "lessons": [
        {
          "id": "u3l1",
          "title": "Mobile Connectors",
          "pages": "40–42",
          "intro": "A physical connection can carry power, data or both. Recognize connector shape and check the cable’s capabilities instead of assuming every cable supports every feature.",
          "points": [
            "The preview covers Mini-USB, Micro-USB, USB-C and Lightning connectors.",
            "USB-C describes a connector; the supported data, charging and video features depend on the device and cable.",
            "USB-to-serial adapters can connect compatible equipment to serial interfaces."
          ],
          "scenario": "A phone charges but does not appear for file transfer. Check cable data support and the device’s USB mode.",
          "questions": [
            {
              "prompt": "Two cables have USB-C plugs. One charges a phone but cannot transfer files. Which conclusion is safest?",
              "options": [
                "Both cables must support identical features",
                "Check cable data support and the phone’s USB mode",
                "The phone’s storage must be damaged",
                "A USB-C plug guarantees video output"
              ],
              "answer": 1,
              "explanation": "Connector shape does not specify every cable capability. A charging-only cable or USB mode may prevent file transfer."
            },
            {
              "prompt": "What does USB-C primarily identify?",
              "options": [
                "A guaranteed data speed",
                "A connector type",
                "A guaranteed video-output capability",
                "A fixed charging wattage"
              ],
              "answer": 1,
              "explanation": "Connector shape alone does not specify all supported protocols or speeds."
            }
          ]
        },
        {
          "id": "u3l2",
          "title": "Bluetooth, NFC & Hotspots",
          "pages": "42–43",
          "intro": "Different wireless tools solve different problems: accessories, close-range transactions and shared Internet access.",
          "points": [
            "Bluetooth supports nearby peripherals, including speakers, earbuds and watches.",
            "NFC supports very short-range interactions such as contactless payments and tag reading.",
            "A mobile hotspot shares Internet access wirelessly. USB tethering uses a cable. Check data-plan restrictions."
          ],
          "scenario": "Your laptop needs Internet access through a phone, but you want a wired link. Choose USB tethering rather than a Wi-Fi hotspot.",
          "questions": [
            {
              "prompt": "A laptop needs Internet access through a phone, but wireless sharing is not allowed. Which supported feature best fits?",
              "options": [
                "NFC payment mode",
                "Bluetooth headset pairing",
                "USB tethering",
                "A Wi-Fi hotspot"
              ],
              "answer": 2,
              "explanation": "USB tethering shares the phone connection over a physical cable. A Wi-Fi hotspot would still be wireless sharing."
            },
            {
              "prompt": "Which option shares a phone connection over a cable?",
              "options": [
                "Wi-Fi hotspot",
                "USB tethering",
                "NFC tag reading",
                "Bluetooth headset pairing"
              ],
              "answer": 1,
              "explanation": "USB tethering creates a wired connection to share Internet access."
            }
          ]
        },
        {
          "id": "u3l3",
          "title": "Accessories, Storage & Protection",
          "pages": "43–44",
          "intro": "Accessories extend a device’s capabilities, but support varies by model. Check specifications before buying storage, charging or input accessories.",
          "points": [
            "A microSD card expands persistent storage only when the device supports it.",
            "Headsets and speakers may connect through audio jacks, USB or Bluetooth.",
            "Ingress-protection ratings have separate dust and water digits. Follow the manufacturer’s tested conditions; a rating is not permission for unlimited immersion."
          ],
          "scenario": "A user wants extra storage. Confirm that their phone has a supported microSD slot before recommending a card.",
          "questions": [
            {
              "prompt": "A phone has an IP68 rating. What is the best advice before exposing it to water?",
              "options": [
                "Any depth is safe if exposure is brief",
                "The first digit defines water depth",
                "Opening the case cannot affect protection",
                "Check the manufacturer’s stated test conditions"
              ],
              "answer": 3,
              "explanation": "IP ratings describe tested protection levels. Exact water conditions and limitations depend on the manufacturer; the rating does not mean unlimited immersion."
            },
            {
              "prompt": "What do the two digits of an IP rating describe?",
              "options": [
                "Screen size and pixel count",
                "Dust and water protection",
                "Battery capacity and voltage",
                "Wireless range and throughput"
              ],
              "answer": 1,
              "explanation": "The first digit concerns solids such as dust; the second concerns water."
            }
          ]
        },
        {
          "id": "u3l4",
          "title": "Docks, Replicators & Input Tools",
          "pages": "44–45",
          "intro": "A dock or port replicator extends a laptop’s connections. A stylus or drawing pad can improve precise input.",
          "points": [
            "Docks may provide displays, networking, USB and power delivery, depending on the model.",
            "A port replicator primarily exposes extra ports. Product names overlap, so verify actual features.",
            "Check operating-system support and device compatibility for drawing pads, trackpads and touch pens."
          ],
          "scenario": "A learner wants a keyboard, monitor and Ethernet at a desk. Compare compatible docks by ports, display support and charging requirements.",
          "questions": [
            {
              "prompt": "A user needs one desktop connection for two displays, Ethernet, keyboard and laptop charging. What should you verify when choosing a dock?",
              "options": [
                "Port, display and power-delivery compatibility",
                "Only the number of USB sockets",
                "Only whether the plug physically fits",
                "That every dock supports identical charging power"
              ],
              "answer": 0,
              "explanation": "A dock must meet the host’s interface, monitor and power requirements. Physical fit alone is not enough."
            },
            {
              "prompt": "Which accessory helps with accurate on-screen writing?",
              "options": [
                "A port replicator",
                "Stylus",
                "A charging-only cable",
                "A cable lock"
              ],
              "answer": 1,
              "explanation": "A supported stylus provides more precise input than a finger for many tasks."
            }
          ]
        }
      ]
    },
    {
      "id": "u4",
      "title": "Connectivity & Application Support",
      "chapter": 4,
      "pages": "49–69",
      "lessons": [
        {
          "id": "u4l1",
          "title": "Wi-Fi & Airplane Mode",
          "pages": "50–52",
          "intro": "To join Wi-Fi, select the intended network, provide the correct credentials and verify connectivity. Diagnose radio state before changing deeper settings.",
          "points": [
            "An SSID is the Wi-Fi network name.",
            "Use the network’s supported secure settings and correct credentials. An association alone does not guarantee Internet access.",
            "Airplane mode primarily restricts cellular radio use. Wi-Fi and Bluetooth can often be re-enabled separately; behavior depends on device settings."
          ],
          "scenario": "A phone suddenly loses cellular service. Check airplane mode and radio settings before assuming the SIM is damaged.",
          "questions": [
            {
              "prompt": "A phone is connected to a Wi-Fi SSID but cannot open websites. What can you conclude from association alone?",
              "options": [
                "The Internet connection is definitely working",
                "The phone has joined the WLAN, but Internet access still needs testing",
                "The cellular SIM must be working",
                "The mail server credentials are correct"
              ],
              "answer": 1,
              "explanation": "Joining a WLAN establishes a local wireless association. It does not prove Internet reachability or application configuration."
            },
            {
              "prompt": "A phone loses cellular service after a quick-settings change. What should you check first?",
              "options": [
                "A disabled camera permission",
                "Airplane mode",
                "The email synchronization interval",
                "The USB file-transfer mode"
              ],
              "answer": 1,
              "explanation": "Airplane mode can disable cellular connectivity."
            }
          ]
        },
        {
          "id": "u4l2",
          "title": "Pairing Bluetooth Devices",
          "pages": "53–54",
          "intro": "Pairing creates a trusted association between Bluetooth devices. A paired device may still need to connect before audio or input works.",
          "points": [
            "Enable Bluetooth and put the accessory into pairing or discoverable mode.",
            "Select the intended device and confirm a matching code or PIN if requested.",
            "Test the actual function after pairing. Check charge level and competing connections if pairing fails."
          ],
          "scenario": "Earbuds are listed but play no audio. Check whether they are connected and selected as the audio output.",
          "questions": [
            {
              "prompt": "A headset is listed as paired, but audio still plays through the phone speaker. What should you check before pairing again?",
              "options": [
                "The phone’s email protocol",
                "The laptop’s RAM generation",
                "Whether the headset is connected and selected for audio output",
                "Whether GPS has a satellite fix"
              ],
              "answer": 2,
              "explanation": "A stored pairing is not the same as an active audio connection. Check connection and output selection before repeating setup."
            },
            {
              "prompt": "After pairing a Bluetooth headset, what verifies success?",
              "options": [
                "A saved pairing entry alone",
                "A working audio test",
                "The Bluetooth switch being on alone",
                "The accessory appearing in a scan alone"
              ],
              "answer": 1,
              "explanation": "Testing the intended function confirms more than the device merely appearing in a list."
            }
          ]
        },
        {
          "id": "u4l3",
          "title": "Email Accounts & Ports",
          "pages": "55–57",
          "intro": "Email clients need correct credentials, server names, protocols and security settings. Receiving and sending mail use different protocols.",
          "points": [
            "POP3 and IMAP receive mail; SMTP sends it. IMAP supports server-based mailbox synchronization.",
            "Common implicit-TLS ports are POP3 995, IMAP 993 and SMTP submission 465. Port 587 commonly uses STARTTLS for submission.",
            "Use the administrator or provider settings. A port number by itself does not prove that encryption is active. S/MIME concerns message-level protection."
          ],
          "scenario": "Incoming mail works but outgoing mail fails. Inspect SMTP configuration and authentication rather than changing IMAP at random.",
          "questions": [
            {
              "prompt": "A mail app receives messages using IMAP over TLS on port 993, but sending fails. Which settings should you inspect first?",
              "options": [
                "Change IMAP to port 995",
                "Disable all TLS settings",
                "Replace the SIM card",
                "The SMTP submission server, port and authentication"
              ],
              "answer": 3,
              "explanation": "Receiving works, so focus on the separate sending path. SMTP handles submission; changing a working IMAP configuration does not address that path."
            },
            {
              "prompt": "Which is the common implicit-TLS IMAP port?",
              "options": [
                "995",
                "993",
                "465",
                "587"
              ],
              "answer": 1,
              "explanation": "IMAP over implicit TLS commonly uses port 993."
            }
          ]
        },
        {
          "id": "u4l4",
          "title": "Cellular Networks & Device Identity",
          "pages": "57–61",
          "intro": "Cellular radios provide wide-area service. The preview introduces older and newer cellular generations alongside device and subscription identifiers.",
          "points": [
            "GSM, CDMA and their related systems are historical foundations; the preview also introduces LTE and 5G.",
            "IMEI identifies mobile equipment. IMSI identifies the subscriber identity associated with the subscription.",
            "Baseband firmware controls cellular radio functions. Use supported update procedures rather than experimenting with radio firmware."
          ],
          "scenario": "A carrier asks for the handset identifier. Locate its IMEI in the device information settings.",
          "questions": [
            {
              "prompt": "A carrier wants to identify a handset, rather than the subscriber identity. Which identifier should you provide?",
              "options": [
                "IMEI",
                "IMSI",
                "SSID",
                "The IMAP server name"
              ],
              "answer": 0,
              "explanation": "IMEI identifies the mobile equipment. IMSI identifies the subscriber identity, and SSID identifies a wireless network."
            },
            {
              "prompt": "Which identifier is associated with subscriber identity?",
              "options": [
                "IMSI",
                "IMEI",
                "SSID",
                "MAC address"
              ],
              "answer": 0,
              "explanation": "IMSI is associated with the cellular subscription identity."
            }
          ]
        },
        {
          "id": "u4l5",
          "title": "Location Services",
          "pages": "59–61",
          "intro": "Location services combine geographic information from sources such as satellite positioning and cellular networks. Apps also need appropriate permissions.",
          "points": [
            "GPS uses satellite signals to estimate position.",
            "Cellular network information can also help estimate location.",
            "Geotagging attaches location data to content. Geofencing triggers actions when entering or leaving a defined area. Review location permissions for privacy."
          ],
          "scenario": "A map cannot locate the device. Check location settings and app permissions before replacing hardware.",
          "questions": [
            {
              "prompt": "A delivery app must trigger an action when a phone enters a defined area. Which feature and prerequisite best fit?",
              "options": [
                "USB tethering with a data cable",
                "Geofencing with suitable location access",
                "IMAP with port 993",
                "NFC with airplane mode enabled"
              ],
              "answer": 1,
              "explanation": "Geofencing uses a geographic boundary. The app needs appropriate location capabilities and permission for the required behavior."
            },
            {
              "prompt": "An app reacts when a device enters a defined area. What is this called?",
              "options": [
                "Tethering",
                "Geofencing",
                "Geotagging a photograph",
                "Cloud synchronization"
              ],
              "answer": 1,
              "explanation": "A geofence defines a geographic boundary used to trigger actions."
            }
          ]
        },
        {
          "id": "u4l6",
          "title": "Synchronization & Backups",
          "pages": "61–65",
          "intro": "Synchronization keeps selected data aligned across devices or services. A backup provides a recoverable copy and should be planned separately.",
          "points": [
            "Cloud sync can include files, contacts, calendars and email; check the account and selected categories.",
            "USB file transfer may require selecting a data-transfer mode on the mobile device.",
            "A deletion can propagate through sync. A separate backup or version history helps recover from mistakes. Vehicle integration depends on compatible software, firmware and connections."
          ],
          "scenario": "Deleting a file on one synced device removes it elsewhere. Recover from backup or version history, then review the sync behavior.",
          "questions": [
            {
              "prompt": "A user deletes a synced file and it disappears from all linked devices. What would best provide recovery independent of that sync change?",
              "options": [
                "A second device using the same sync account only",
                "A faster Wi-Fi connection",
                "A separate backup or recoverable version history",
                "A higher-capacity RAM module"
              ],
              "answer": 2,
              "explanation": "Sync can propagate deletions. Recovery requires a preserved copy or version rather than another device reflecting the same deletion."
            },
            {
              "prompt": "A connected phone only charges over USB. Which setting may need changing?",
              "options": [
                "USB file-transfer mode",
                "The email retrieval protocol",
                "The location permission",
                "The display refresh setting"
              ],
              "answer": 0,
              "explanation": "The phone may be in charging-only mode rather than allowing data transfer."
            }
          ]
        },
        {
          "id": "u4l7",
          "title": "Mobile Device Management",
          "pages": "65–66",
          "intro": "MDM lets an organization centrally configure and administer enrolled mobile devices according to policy.",
          "points": [
            "MDM can distribute configurations and applications and enforce security requirements.",
            "Work-device policies may affect camera access, sign-in rules, storage or organizational data.",
            "For an enrollment or policy problem, check the management status and contact the authorized administrator rather than bypassing controls."
          ],
          "scenario": "A work phone cannot install an app. Check whether an MDM policy restricts installation.",
          "questions": [
            {
              "prompt": "A managed work phone blocks a camera feature that works on a personal phone. What is the best first response?",
              "options": [
                "Factory-reset it without checking enrollment",
                "Install an app to bypass the restriction",
                "Remove organizational management immediately",
                "Check the organization’s MDM policy with its administrator"
              ],
              "answer": 3,
              "explanation": "The block may be an intentional security policy. Confirm management requirements rather than bypassing or removing controls."
            },
            {
              "prompt": "An enrolled work phone blocks an app. What is a sensible next action?",
              "options": [
                "Bypass management controls",
                "Check policy with the authorized administrator",
                "Factory-reset without approval",
                "Use a personal account to evade enrollment"
              ],
              "answer": 1,
              "explanation": "The restriction may be an intentional organizational policy."
            }
          ]
        }
      ]
    }
  ],
  "outline": [
    {
      "chapter": 1,
      "title": "Laptop Hardware and Components",
      "available": true
    },
    {
      "chapter": 2,
      "title": "Mobile Device Display Components",
      "available": true
    },
    {
      "chapter": 3,
      "title": "Mobile Device Accessories and Ports",
      "available": true
    },
    {
      "chapter": 4,
      "title": "Mobile Device Network Connectivity and Application Support",
      "available": true
    },
    {
      "chapter": 5,
      "title": "TCP and UDP Ports and Protocols",
      "available": false
    },
    {
      "chapter": 6,
      "title": "Network Devices",
      "available": false
    },
    {
      "chapter": 7,
      "title": "Wireless Protocols",
      "available": false
    },
    {
      "chapter": 8,
      "title": "Networked Hosts",
      "available": false
    },
    {
      "chapter": 9,
      "title": "SOHO Network Configuration",
      "available": false
    },
    {
      "chapter": 10,
      "title": "Network Configuration Concepts",
      "available": false
    },
    {
      "chapter": 11,
      "title": "Network Types",
      "available": false
    },
    {
      "chapter": 12,
      "title": "Networking Tools",
      "available": false
    },
    {
      "chapter": 13,
      "title": "Cables and Connectors",
      "available": false
    },
    {
      "chapter": 14,
      "title": "RAM",
      "available": false
    },
    {
      "chapter": 15,
      "title": "Storage Drives",
      "available": false
    },
    {
      "chapter": 16,
      "title": "Motherboards and Add-on Cards",
      "available": false
    },
    {
      "chapter": 17,
      "title": "CPUs",
      "available": false
    },
    {
      "chapter": 18,
      "title": "Power",
      "available": false
    },
    {
      "chapter": 19,
      "title": "Multifunction Devices/Printers",
      "available": false
    },
    {
      "chapter": 20,
      "title": "Printer Consumables",
      "available": false
    },
    {
      "chapter": 21,
      "title": "Cloud Computing Concepts",
      "available": false
    },
    {
      "chapter": 22,
      "title": "Client-side Virtualization",
      "available": false
    },
    {
      "chapter": 23,
      "title": "Computer Troubleshooting",
      "available": false
    },
    {
      "chapter": 24,
      "title": "Troubleshooting Motherboards, CPUs, RAM, and Power",
      "available": false
    },
    {
      "chapter": 25,
      "title": "Troubleshooting Storage Drives and RAID Arrays",
      "available": false
    },
    {
      "chapter": 26,
      "title": "Troubleshooting Video Issues",
      "available": false
    },
    {
      "chapter": 27,
      "title": "Troubleshooting Mobile Devices",
      "available": false
    },
    {
      "chapter": 28,
      "title": "Troubleshooting Printers",
      "available": false
    },
    {
      "chapter": 29,
      "title": "Troubleshooting Wired and Wireless Network Problems",
      "available": false
    },
    {
      "chapter": 30,
      "title": "Comparing Windows Editions",
      "available": false
    },
    {
      "chapter": 31,
      "title": "Microsoft Command-Line Tools, Part I",
      "available": false
    },
    {
      "chapter": 32,
      "title": "Microsoft Command-Line Tools, Part II",
      "available": false
    },
    {
      "chapter": 33,
      "title": "Microsoft Operating System Features and Tools, Part I",
      "available": false
    },
    {
      "chapter": 34,
      "title": "Microsoft Operating System Features and Tools, Part II",
      "available": false
    },
    {
      "chapter": 35,
      "title": "Windows Control Panel Utilities",
      "available": false
    },
    {
      "chapter": 36,
      "title": "Windows Settings",
      "available": false
    },
    {
      "chapter": 37,
      "title": "Windows Networking",
      "available": false
    },
    {
      "chapter": 38,
      "title": "Application Installation and Configuration Concepts",
      "available": false
    },
    {
      "chapter": 39,
      "title": "Common Operating Systems",
      "available": false
    },
    {
      "chapter": 40,
      "title": "Operating System Installations and Upgrades",
      "available": false
    },
    {
      "chapter": 41,
      "title": "macOS",
      "available": false
    },
    {
      "chapter": 42,
      "title": "Linux",
      "available": false
    },
    {
      "chapter": 43,
      "title": "Physical Security",
      "available": false
    },
    {
      "chapter": 44,
      "title": "Logical Security",
      "available": false
    },
    {
      "chapter": 45,
      "title": "Wireless Security and Malware",
      "available": false
    },
    {
      "chapter": 46,
      "title": "Social Engineering",
      "available": false
    },
    {
      "chapter": 47,
      "title": "Windows Security Settings",
      "available": false
    },
    {
      "chapter": 48,
      "title": "Windows Best Practices",
      "available": false
    },
    {
      "chapter": 49,
      "title": "Mobile Device Security",
      "available": false
    },
    {
      "chapter": 50,
      "title": "Data Destruction and Disposal",
      "available": false
    },
    {
      "chapter": 51,
      "title": "SOHO Security",
      "available": false
    },
    {
      "chapter": 52,
      "title": "Browser Security",
      "available": false
    },
    {
      "chapter": 53,
      "title": "Troubleshooting Microsoft Windows",
      "available": false
    },
    {
      "chapter": 54,
      "title": "Troubleshooting PC Security Issues",
      "available": false
    },
    {
      "chapter": 55,
      "title": "Troubleshooting Mobile Operating Systems and Applications",
      "available": false
    },
    {
      "chapter": 56,
      "title": "Troubleshooting Mobile Operating Systems Security Issues",
      "available": false
    },
    {
      "chapter": 57,
      "title": "Documentation",
      "available": false
    },
    {
      "chapter": 58,
      "title": "Change Management and Backup Methods",
      "available": false
    },
    {
      "chapter": 59,
      "title": "Safety Procedures",
      "available": false
    },
    {
      "chapter": 60,
      "title": "Environmental Controls",
      "available": false
    },
    {
      "chapter": 61,
      "title": "Incident Response, Communication, and Professionalism",
      "available": false
    },
    {
      "chapter": 62,
      "title": "Basic Scripting, Part I",
      "available": false
    },
    {
      "chapter": 63,
      "title": "Basic Scripting, Part II",
      "available": false
    },
    {
      "chapter": 64,
      "title": "Remote Access Technologies",
      "available": false
    },
    {
      "chapter": 65,
      "title": "Getting Ready for the Exams, and Farewell",
      "available": false
    }
  ]
};
