Reserved for future icons artwork. No graphical assets are included in this build.
