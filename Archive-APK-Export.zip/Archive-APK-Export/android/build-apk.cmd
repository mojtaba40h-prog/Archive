@echo off
cd /d "%~dp0"
where gradle >nul 2>nul
if errorlevel 1 (
  echo Install Gradle 8.11.1 and Java 17, or use the included GitHub Actions workflow.
  exit /b 1
)
gradle --no-daemon :app:assembleDebug
