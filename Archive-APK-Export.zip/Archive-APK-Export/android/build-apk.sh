#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null; then
  echo 'Install Gradle 8.11.1 and Java 17, or use the included GitHub Actions workflow.' >&2
  exit 1
fi
gradle --no-daemon :app:assembleDebug
printf '\nAPK: %s/app/build/outputs/apk/debug/app-debug.apk\n' "$PWD"
