# ARCHIVE Android shell

Java WebView app using AndroidX WebViewAssetLoader with a stable local HTTPS origin.
The web app, 144 lessons, three mentors, nine looks and transparent chibi sheets are bundled.
No website login, server, API key or network permission is required at runtime.

## Build

Pinned toolchain: Java 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2, SDK/target 35,
build tools 35.0.0; AndroidX WebKit 1.12.1. Minimum Android version: 8.0 / API 26.

From the `android` directory, with those dependencies installed:

```sh
gradle --no-daemon :app:assembleDebug
```

Or run `build-apk.sh` (`build-apk.cmd` on Windows). The included GitHub Actions workflow
installs the build environment and produces the APK without requiring a local SDK.
A Gradle wrapper binary is not included; the workflow provides the pinned Gradle version.
If desired, an installed Gradle can create a wrapper with `gradle wrapper --gradle-version 8.11.1`.

Output: `app/build/outputs/apk/debug/app-debug.apk`.

`stageArchiveAssets` copies `../web` (in the export), or `../dist` (in the Site source),
into generated Android assets, stripping external font imports. Edit the web source,
then rebuild; there is no need to maintain a second copy inside `src/main/assets`.

The debug APK is for installation/testing. For repeatable updates, keep the same signing
key and application ID; a new CI runner's debug key can differ. A release for store
publication needs your own signing configuration and review of current store requirements.
No private signing key is included.

## Progress

localStorage uses the stable `appassets.androidplatform.net` origin. Updating an installed
app with the same application ID/signing key retains its data. Browser/Sites progress is
not automatically transferred into the APK. Uninstalling the app or clearing its data
removes its local progress. In-app reset keeps display name/language/free chibi preference
but resets lessons, XP, achievements, purchased looks/palettes and gems to 240.

## Validation limit

JavaScript, asset inventory, XML structure and reset behavior were checked. This export
has not been compiled or run on an Android device in the authoring environment because
an Android SDK/Gradle installation is not available there.

## Official implementation references

- https://developer.android.com/develop/ui/views/layout/webapps/load-local-content
- https://developer.android.com/build/releases/agp-8-9-0-release-notes
- https://developer.android.com/jetpack/androidx/releases/webkit#1.12.1
