# ARCHIVE — complete Android export

See `README-AR.md` for Arabic instructions.

Contents: 144 bilingual lessons across six paths, quizzes, all images, three mentors,
nine outfits, 24 achievements, four transparent chibi companions with seven poses each,
and the confirmed progress-reset option.

- `web/`: complete self-contained static application; system-font fallback for offline use.
- `android/`: Java Android WebView shell with local HTTPS asset loading and persistent storage.
- `.github/workflows/build-apk.yml`: manually triggered installable debug APK build.
- `export-info.json` and `CHECKSUMS.sha256`: content inventory and integrity records.

This is source/project export, not a precompiled APK. Android compilation and on-device
execution were not performed because the authoring environment has no Android SDK/Gradle.
JavaScript/reset behavior, file references and Android XML were checked.

## Build in GitHub Actions

Unzip, put the **contents** of `Archive-APK-Export` at your repository root, including
`.github`. GitHub does not expand an uploaded ZIP automatically. Open Actions, choose
`Build Android APK`, run it, then download the `Archive-APK` artifact after success.

## Local build

Install Java 17, Gradle 8.11.1, SDK 35 and build tools 35.0.0; run:

```sh
cd android
gradle --no-daemon :app:assembleDebug
```

Output: `android/app/build/outputs/apk/debug/app-debug.apk`.
The first build downloads dependencies. Build tools/SDK and the Gradle wrapper binary
are not included; CI provisions the pinned build environment.

## Runtime and data

The installed app bundles its content and runs offline without a Sites/ChatGPT login.
Browser progress is not transferred automatically. Reset clears local learning, reward
and paid-customization state, returns gems to 240, and keeps name/language/free chibi
preference. It does not remove bundled content. Use the same application ID and signing
key to retain data across app updates. Debug keys can differ on separate CI runners;
use your own stable release-signing setup for updates/distribution.

See `android/README.md` for pinned versions, implementation notes and official references.
